import os
import sys

print("test")